Hook
====

Lightweight API hooking framework for the Windows API
